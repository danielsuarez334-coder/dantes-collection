import React, { useState, useEffect } from "react";
import PinLogin from "./components/PinLogin";
import NewOrderTab from "./components/NewOrderTab";
import OrdersTab from "./components/OrdersTab";
import InventoryTab from "./components/InventoryTab";
import ReportsTab from "./components/ReportsTab";
import StreamlitCodeTab from "./components/StreamlitCodeTab";
import { InventoryItem, Order, ShirtModel, ShirtColor, ShirtSize } from "./types";
import { Crown, LogOut, ShoppingBag, Layers, BarChart3, HelpCircle, Code } from "lucide-react";

// Initializing the 24 variants
const createInitialInventory = (): InventoryItem[] => {
  const models: ShirtModel[] = ["Oversized", "Algodón Licrado"];
  const colors: ShirtColor[] = ["Negro", "Blanco", "Beige"];
  const sizes: ShirtSize[] = ["S", "M", "L", "XL"];
  
  const items: InventoryItem[] = [];
  let id = 1;
  
  for (const model of models) {
    for (const color of colors) {
      for (const size of sizes) {
        items.push({
          id,
          name: `Camisa ${model} ${color} ${size}`,
          model,
          color,
          size,
          stock_liso: 35, // Prepopulated with 35 items each
          stock_apartado: 0,
          stock_estampado: 0
        });
        id++;
      }
    }
  }
  return items;
};

// Simple pre-loaded orders to populate statistics beautifully
const preloadedOrders: Order[] = [
  {
    id: 1,
    customerName: "Carlos Pérez",
    model: "Oversized",
    color: "Negro",
    size: "M",
    quantity: 3,
    printDesign: "Letras Dante Doradas",
    status: "Finalizado",
    createdAt: "2026-07-02 14:32:00",
    notes: "Cliente recurrente de Medellín",
    vendedor: "Daniel"
  },
  {
    id: 2,
    customerName: "Camila Restrepo",
    model: "Algodón Licrado",
    color: "Blanco",
    size: "S",
    quantity: 5,
    printDesign: "Mini corona frontal",
    status: "Pendiente",
    createdAt: "2026-07-04 10:15:00",
    notes: "Entregar urgente",
    vendedor: "Slendy"
  },
  {
    id: 3,
    customerName: "Mateo Giraldo",
    model: "Oversized",
    color: "Beige",
    size: "XL",
    quantity: 2,
    printDesign: "Liso (Sin estampado)",
    status: "Finalizado",
    createdAt: "2026-07-01 17:40:00",
    notes: "Desea factura electrónica",
    vendedor: "Daniel"
  }
];

export default function App() {
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loggedInUser, setLoggedInUser] = useState<"Daniel" | "Slendy" | null>(null);
  const [activeTab, setActiveTab] = useState<"nuevo" | "gestion" | "inventario" | "reportes" | "streamlit">("nuevo");

  // Load from localStorage or initialize
  useEffect(() => {
    const savedInv = localStorage.getItem("dantes_inventory");
    const savedOrders = localStorage.getItem("dantes_orders");
    const savedUser = localStorage.getItem("dantes_user");

    if (savedInv) {
      setInventory(JSON.parse(savedInv));
    } else {
      // Initialize inventory and apply stock adjustments for preloaded orders
      const initialInv = createInitialInventory();
      // Adjust stock according to preloaded orders
      preloadedOrders.forEach((o) => {
        const item = initialInv.find(
          (invItem) => invItem.model === o.model && invItem.color === o.color && invItem.size === o.size
        );
        if (item) {
          if (o.status === "Finalizado") {
            item.stock_liso -= o.quantity;
            item.stock_estampado += o.quantity;
          } else if (o.status === "Pendiente") {
            item.stock_liso -= o.quantity;
            item.stock_apartado += o.quantity;
          }
        }
      });
      setInventory(initialInv);
      localStorage.setItem("dantes_inventory", JSON.stringify(initialInv));
    }

    if (savedOrders) {
      setOrders(JSON.parse(savedOrders));
    } else {
      setOrders(preloadedOrders);
      localStorage.setItem("dantes_orders", JSON.stringify(preloadedOrders));
    }

    if (savedUser) {
      setLoggedInUser(savedUser as "Daniel" | "Slendy");
    }
  }, []);

  // Sync utilities
  const saveToLocal = (newInv: InventoryItem[], newOrders: Order[]) => {
    setInventory(newInv);
    setOrders(newOrders);
    localStorage.setItem("dantes_inventory", JSON.stringify(newInv));
    localStorage.setItem("dantes_orders", JSON.stringify(newOrders));
  };

  const handleLoginSuccess = (vendedor: "Daniel" | "Slendy") => {
    setLoggedInUser(vendedor);
    localStorage.setItem("dantes_user", vendedor);
  };

  const handleLogout = () => {
    setLoggedInUser(null);
    localStorage.removeItem("dantes_user");
  };

  // REGISTER ORDER
  const handleRegisterOrder = (newOrderData: Omit<Order, "id" | "createdAt" | "status">) => {
    const newId = orders.length > 0 ? Math.max(...orders.map((o) => o.id)) + 1 : 1;
    const now = new Date();
    const createdAt = now.toISOString().replace("T", " ").substring(0, 19);

    const newOrder: Order = {
      ...newOrderData,
      id: newId,
      createdAt,
      status: "Pendiente"
    };

    // Update stocks: subtract from stock_liso, add to stock_apartado
    const updatedInventory = inventory.map((item) => {
      if (item.model === newOrder.model && item.color === newOrder.color && item.size === newOrder.size) {
        return {
          ...item,
          stock_liso: item.stock_liso - newOrder.quantity,
          stock_apartado: item.stock_apartado + newOrder.quantity
        };
      }
      return item;
    });

    const updatedOrders = [newOrder, ...orders];
    saveToLocal(updatedInventory, updatedOrders);
  };

  // COMPLETE ORDER
  const handleCompleteOrder = (orderId: number) => {
    const orderToComplete = orders.find((o) => o.id === orderId);
    if (!orderToComplete) return;

    // Update stocks: subtract from stock_apartado, add to stock_estampado
    const updatedInventory = inventory.map((item) => {
      if (
        item.model === orderToComplete.model &&
        item.color === orderToComplete.color &&
        item.size === orderToComplete.size
      ) {
        return {
          ...item,
          stock_apartado: item.stock_apartado - orderToComplete.quantity,
          stock_estampado: item.stock_estampado + orderToComplete.quantity
        };
      }
      return item;
    });

    const updatedOrders = orders.map((o) => (o.id === orderId ? { ...o, status: "Finalizado" as const } : o));
    saveToLocal(updatedInventory, updatedOrders);
  };

  // CANCEL ORDER
  const handleCancelOrder = (orderId: number) => {
    const orderToCancel = orders.find((o) => o.id === orderId);
    if (!orderToCancel) return;

    // Update stocks: add back to stock_liso, subtract from stock_apartado
    const updatedInventory = inventory.map((item) => {
      if (
        item.model === orderToCancel.model &&
        item.color === orderToCancel.color &&
        item.size === orderToCancel.size
      ) {
        return {
          ...item,
          stock_liso: item.stock_liso + orderToCancel.quantity,
          stock_apartado: item.stock_apartado - orderToCancel.quantity
        };
      }
      return item;
    });

    const updatedOrders = orders.map((o) => (o.id === orderId ? { ...o, status: "Cancelado" as const } : o));
    saveToLocal(updatedInventory, updatedOrders);
  };

  // MANUAL RE-STOCK LISO
  const handleAddStock = (itemId: number, qtyToAdd: number) => {
    const updatedInventory = inventory.map((item) => {
      if (item.id === itemId) {
        return {
          ...item,
          stock_liso: item.stock_liso + qtyToAdd
        };
      }
      return item;
    });
    saveToLocal(updatedInventory, orders);
  };

  if (!loggedInUser) {
    return <PinLogin onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-[#f5f5f5] flex flex-col justify-between pb-10 font-sans">
      {/* Top Header Bar */}
      <header className="border-b border-[#d4af37]/20 bg-[#121212] py-4 px-4 sticky top-0 z-50">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 border border-[#d4af37]/30 flex items-center justify-center bg-[#0A0A0A]">
              <Crown className="w-4 h-4 text-[#d4af37]" />
            </div>
            <div>
              <h1 className="font-serif text-sm font-bold tracking-[0.2em] text-[#d4af37] uppercase leading-none">
                DANTE'S
              </h1>
              <span className="text-[8px] uppercase tracking-[0.3em] text-stone-500 font-bold block mt-0.5">
                Collection
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right">
              <span className="text-[8px] uppercase tracking-[0.2em] text-stone-500 font-semibold block">
                Vendedor
              </span>
              <span className="text-xs text-[#d4af37] font-semibold">{loggedInUser}</span>
            </div>
            <button
              onClick={handleLogout}
              className="p-1.5 border border-stone-800 bg-stone-950 text-stone-400 hover:text-rose-400 active:scale-95 transition-all"
              title="Cerrar sesión"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Primary Dashboard Container */}
      <main className="flex-1 w-full max-w-md mx-auto px-4 pt-6 pb-24">
        {activeTab === "nuevo" && (
          <NewOrderTab
            inventory={inventory}
            vendedorSesion={loggedInUser}
            onRegisterOrder={handleRegisterOrder}
          />
        )}
        {activeTab === "gestion" && (
          <OrdersTab
            orders={orders}
            onCompleteOrder={handleCompleteOrder}
            onCancelOrder={handleCancelOrder}
          />
        )}
        {activeTab === "inventario" && (
          <InventoryTab inventory={inventory} onAddStock={handleAddStock} />
        )}
        {activeTab === "reportes" && <ReportsTab orders={orders} inventory={inventory} />}
        {activeTab === "streamlit" && <StreamlitCodeTab />}
      </main>

      {/* Premium Luxury Curved Sticky Bottom Nav (Mobile/Cellular Optimized) */}
      <nav className="fixed bottom-0 left-0 right-0 border-t border-[#d4af37]/20 bg-[#121212]/95 backdrop-blur-md py-3 px-4 z-50">
        <div className="max-w-md mx-auto flex items-center justify-around">
          <button
            onClick={() => setActiveTab("nuevo")}
            className={`flex flex-col items-center gap-1 py-1 px-2 transition-all ${
              activeTab === "nuevo" ? "text-[#d4af37]" : "text-stone-500 hover:text-stone-300"
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span className="text-[9px] uppercase tracking-[0.15em] font-medium">Nuevo</span>
          </button>

          <button
            onClick={() => setActiveTab("gestion")}
            className={`flex flex-col items-center gap-1 py-1 px-2 transition-all ${
              activeTab === "gestion" ? "text-[#d4af37]" : "text-stone-500 hover:text-stone-300"
            }`}
          >
            <Layers className="w-4 h-4" />
            <span className="text-[9px] uppercase tracking-[0.15em] font-medium">Gestión</span>
          </button>

          <button
            onClick={() => setActiveTab("inventario")}
            className={`flex flex-col items-center gap-1 py-1 px-2 transition-all ${
              activeTab === "inventario" ? "text-[#d4af37]" : "text-stone-500 hover:text-stone-300"
            }`}
          >
            <Crown className="w-4 h-4" />
            <span className="text-[9px] uppercase tracking-[0.15em] font-medium">Stock</span>
          </button>

          <button
            onClick={() => setActiveTab("reportes")}
            className={`flex flex-col items-center gap-1 py-1 px-2 transition-all ${
              activeTab === "reportes" ? "text-[#d4af37]" : "text-stone-500 hover:text-stone-300"
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span className="text-[9px] uppercase tracking-[0.15em] font-medium">Métricas</span>
          </button>

          <button
            onClick={() => setActiveTab("streamlit")}
            className={`flex flex-col items-center gap-1 py-1 px-2 transition-all ${
              activeTab === "streamlit" ? "text-[#d4af37]" : "text-stone-500 hover:text-stone-300"
            }`}
          >
            <Code className="w-4 h-4" />
            <span className="text-[9px] uppercase tracking-[0.15em] font-medium">Python</span>
          </button>
        </div>
      </nav>

      {/* Mini Branding Footer */}
      <footer className="text-center text-stone-600 text-[9px] uppercase tracking-[0.25em] mt-6">
        <span>Dante's Collection © 2026</span>
      </footer>
    </div>
  );
}
