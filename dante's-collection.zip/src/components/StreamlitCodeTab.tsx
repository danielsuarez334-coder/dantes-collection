import React, { useState } from "react";
import { Code, Copy, Check, FileCode, HelpCircle } from "lucide-react";

export default function StreamlitCodeTab() {
  const [copiedApp, setCopiedApp] = useState(false);
  const [copiedReqs, setCopiedReqs] = useState(false);
  const [copiedSecrets, setCopiedSecrets] = useState(false);

  const codeApp = `import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import datetime
from streamlit_gsheets import GSheetsConnection

# ==========================================
# 1. CONFIGURACIÓN DE PÁGINA E IDENTIDAD
# ==========================================
st.set_page_config(
    page_title="Dante's Collection",
    page_icon="👑",
    layout="centered",
    initial_sidebar_state="collapsed"
)

# Estilos CSS personalizados para la paleta de colores: Negro, Dorado y Blanco
st.markdown("""
    <style>
    .stApp {
        background-color: #0d0d0d;
        color: #ffffff;
    }
    h1, h2, h3, .gold-text {
        color: #f39c12 !important;
        font-family: 'Helvetica Neue', Arial, sans-serif;
        font-weight: bold;
        text-align: center;
    }
    .card {
        background-color: #1a1a1a;
        padding: 20px;
        border-radius: 10px;
        border: 1px solid #f39c12;
        margin-bottom: 15px;
    }
    div[data-baseweb="select"] > div, div[data-baseweb="input"] > div {
        background-color: #222222 !important;
        color: #ffffff !important;
        border-color: #f39c12 !important;
    }
    .stButton>button {
        background-color: #f39c12 !important;
        color: #000000 !important;
        font-weight: bold !important;
        border: none !important;
        border-radius: 5px !important;
        width: 100%;
        transition: all 0.3s ease;
    }
    .stButton>button:hover {
        background-color: #e67e22 !important;
        color: #000000 !important;
        box-shadow: 0 0 10px #f39c12;
    }
    .stTabs [data-baseweb="tab-list"] {
        gap: 8px;
        background-color: #111111;
        padding: 5px;
        border-radius: 8px;
    }
    .stTabs [data-baseweb="tab"] {
        height: 45px;
        white-space: pre-wrap;
        background-color: #1a1a1a;
        border-radius: 5px;
        color: #cccccc;
        font-size: 14px;
        border: 1px solid #333333;
    }
    .stTabs [aria-selected="true"] {
        background-color: #f39c12 !important;
        color: #000000 !important;
        font-weight: bold;
        border: 1px solid #f39c12 !important;
    }
    </style>
""", unsafe_allow_html=True)

st.markdown("<h1>👑 DANTE'S COLLECTION 👑</h1>", unsafe_allow_html=True)
st.markdown("<p style='text-align: center; color: #888888; font-style: italic;'>Taller de Camisas Exclusive</p>", unsafe_allow_html=True)

# ==========================================
# 2. SISTEMA DE SEGURIDAD (PIN)
# ==========================================
if "authenticated" not in st.session_state:
    st.session_state.authenticated = False
if "usuario" not in st.session_state:
    st.session_state.usuario = ""

if not st.session_state.authenticated:
    st.markdown("<div class='card'>", unsafe_allow_html=True)
    st.markdown("<h3 style='color: #f39c12; text-align: center;'>🔒 Acceso Privado</h3>", unsafe_allow_html=True)
    pin_input = st.text_input("Ingrese su PIN de Acceso:", type="password")
    col1, col2 = st.columns(2)
    with col1:
        vendedor_login = st.selectbox("¿Quién ingresa?", ["Daniel", "Slendy"])
    with col2:
        st.write("")
        st.write("")
        btn_login = st.button("Ingresar")
    if btn_login:
        if pin_input in ["2026", "1234"]:
            st.session_state.authenticated = True
            st.session_state.usuario = vendedor_login
            st.success(f"¡Bienvenido, {vendedor_login}!")
            st.rerun()
        else:
            st.error("❌ PIN Incorrecto.")
    st.markdown("</div>", unsafe_allow_html=True)
    st.stop()

st.markdown(f"<p style='text-align: right; color: #f39c12; font-weight: bold;'>👤 Sesión: {st.session_state.usuario}</p>", unsafe_allow_html=True)

# ==========================================
# 3. CONEXIÓN A GOOGLE SHEETS
# ==========================================
conn = st.connection("gsheets", type=GSheetsConnection)

@st.cache_data(ttl=5)
def cargar_inventario():
    try:
        df = conn.read(worksheet="Inventario", ttl=5)
        df.columns = [c.strip() for c in df.columns]
        return df
    except:
        # Inicialización de 24 variantes por defecto si no existen
        modelos = ["Oversized", "Algodón Licrado"]
        colores = ["Negro", "Blanco", "Beige"]
        tallas = ["S", "M", "L", "XL"]
        rows = []
        idx = 1
        for model in modelos:
            for color in colores:
                for size in tallas:
                    rows.append({
                        "id": idx, "name": f"Camisa {model} {color} {size}",
                        "color": color, "size": size,
                        "stock_liso": 50, "stock_apartado": 0, "stock_estampado": 0
                    })
                    idx += 1
        return pd.DataFrame(rows)

@st.cache_data(ttl=5)
def cargar_pedidos():
    try:
        df = conn.read(worksheet="Pedidos", ttl=5)
        df.columns = [c.strip() for c in df.columns]
        return df
    except:
        return pd.DataFrame(columns=[
            "id", "customerName", "model", "color", "size", 
            "quantity", "printDesign", "status", "createdAt", "notes", "vendedor"
        ])

df_inv = cargar_inventario()
df_ped = cargar_pedidos()

# Ajustar formatos numéricos
df_inv["id"] = df_inv["id"].astype(int)
df_inv["stock_liso"] = df_inv["stock_liso"].astype(int)
df_inv["stock_apartado"] = df_inv["stock_apartado"].astype(int)
df_inv["stock_estampado"] = df_inv["stock_estampado"].astype(int)
if not df_ped.empty:
    df_ped["id"] = df_ped["id"].astype(int)
    df_ped["quantity"] = df_ped["quantity"].astype(int)

# ==========================================
# 4. TABS
# ==========================================
tab_nuevo, tab_gestion, tab_inventario, tab_reportes = st.tabs([
    "🛒 Nuevo Pedido", "📦 Gestión", "🗃️ Inventario", "📊 Reportes"
])

# -- NUEVO PEDIDO --
with tab_nuevo:
    st.markdown("<h3 style='color: #f39c12;'>📝 Registrar Pedido</h3>", unsafe_allow_html=True)
    with st.form("form_pedido"):
        customer_name = st.text_input("Cliente:")
        model_select = st.selectbox("Modelo:", ["Oversized", "Algodón Licrado"])
        color_select = st.selectbox("Color:", sorted(df_inv["color"].unique()))
        size_select = st.selectbox("Talla:", ["S", "M", "L", "XL"])
        
        match_inv = df_inv[(df_inv["name"].str.contains(model_select)) & (df_inv["color"] == color_select) & (df_inv["size"] == size_select)]
        stock_disponible = int(match_inv.iloc[0]["stock_liso"]) if not match_inv.empty else 0
        variant_id = int(match_inv.iloc[0]["id"]) if not match_inv.empty else None
        
        st.info(f"💡 Stock liso disponible: {stock_disponible} unidades.")
        quantity = st.number_input("Cantidad:", min_value=1, value=1, step=1)
        print_design = st.text_input("Diseño del Estampado:")
        notes = st.text_area("Notas:")
        vendedor_pedido = st.selectbox("Vendedor:", ["Daniel", "Slendy"])
        
        btn_registrar = st.form_submit_button("Confirmar Pedido 🚀")
        if btn_registrar:
            if not customer_name.strip():
                st.error("Ingrese el nombre del cliente.")
            elif quantity > stock_disponible:
                st.error("Stock liso insuficiente.")
            else:
                # Restar stock liso, sumar apartado
                df_inv.loc[df_inv["id"] == variant_id, "stock_liso"] -= quantity
                df_inv.loc[df_inv["id"] == variant_id, "stock_apartado"] += quantity
                
                new_id = 1 if df_ped.empty else int(df_ped["id"].max()) + 1
                new_order = pd.DataFrame([{
                    "id": new_id, "customerName": customer_name.strip(), "model": model_select,
                    "color": color_select, "size": size_select, "quantity": int(quantity),
                    "printDesign": print_design if print_design.strip() else "Liso",
                    "status": "Pendiente", "createdAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "notes": notes, "vendedor": vendedor_pedido
                }])
                df_ped = pd.concat([df_ped, new_order], ignore_index=True)
                
                conn.update(worksheet="Inventario", data=df_inv)
                conn.update(worksheet="Pedidos", data=df_ped)
                st.success("¡Pedido registrado exitosamente!")
                st.rerun()

# -- GESTIÓN --
with tab_gestion:
    st.markdown("<h3 style='color: #f39c12;'>📦 Gestión de Pedidos</h3>", unsafe_allow_html=True)
    if df_ped.empty:
        st.info("No hay pedidos.")
    else:
        for idx, row in df_ped.iterrows():
            with st.container():
                st.markdown(f"<div class='card'><b>Pedido #{row['id']} - {row['customerName']}</b><br>Cantidad: {row['quantity']} | Vendedor: {row['vendedor']} | Estado: {row['status']}</div>", unsafe_allow_html=True)
                if row["status"] == "Pendiente":
                    col1, col2 = st.columns(2)
                    with col1:
                        if st.button(f"Completar #{row['id']}", key=f"c_{row['id']}"):
                            # Restar apartado, sumar estampado
                            match_v = df_inv[(df_inv["name"].str.contains(row['model'])) & (df_inv["color"] == row['color']) & (df_inv["size"] == row['size'])]
                            if not match_v.empty:
                                v_id = match_v.iloc[0]["id"]
                                df_inv.loc[df_inv["id"] == v_id, "stock_apartado"] -= int(row['quantity'])
                                df_inv.loc[df_inv["id"] == v_id, "stock_estampado"] += int(row['quantity'])
                                df_ped.loc[df_ped["id"] == row["id"], "status"] = "Finalizado"
                                conn.update(worksheet="Inventario", data=df_inv)
                                conn.update(worksheet="Pedidos", data=df_ped)
                                st.success("Pedido completado.")
                                st.rerun()
                    with col2:
                        if st.button(f"Cancelar #{row['id']}", key=f"x_{row['id']}"):
                            # Devolver apartado a liso
                            match_v = df_inv[(df_inv["name"].str.contains(row['model'])) & (df_inv["color"] == row['color']) & (df_inv["size"] == row['size'])]
                            if not match_v.empty:
                                v_id = match_v.iloc[0]["id"]
                                df_inv.loc[df_inv["id"] == v_id, "stock_apartado"] -= int(row['quantity'])
                                df_inv.loc[df_inv["id"] == v_id, "stock_liso"] += int(row['quantity'])
                                df_ped.loc[df_ped["id"] == row["id"], "status"] = "Cancelado"
                                conn.update(worksheet="Inventario", data=df_inv)
                                conn.update(worksheet="Pedidos", data=df_ped)
                                st.success("Pedido cancelado.")
                                st.rerun()

# -- INVENTARIO --
with tab_inventario:
    st.markdown("<h3 style='color: #f39c12;'>🗃️ Inventario</h3>", unsafe_allow_html=True)
    st.dataframe(df_inv[["id", "name", "stock_liso", "stock_apartado", "stock_estampado"]], use_container_width=True, hide_index=True)

# -- REPORTES --
with tab_reportes:
    st.markdown("<h3 style='color: #f39c12;'>📊 Reportes</h3>", unsafe_allow_html=True)
    if not df_ped.empty:
        df_ventas = df_ped[df_ped["status"] != "Cancelado"]
        sales_by_vendedor = df_ventas.groupby("vendedor")["quantity"].sum().reset_index()
        fig = px.bar(sales_by_vendedor, x="vendedor", y="quantity", color="vendedor", template="plotly_dark", color_discrete_sequence=["#f39c12"])
        st.plotly_chart(fig, use_container_width=True)
`;

  const codeReqs = `streamlit>=1.35.0
pandas>=2.0.0
plotly>=5.18.0
streamlit-gsheets>=0.0.3`;

  const codeSecrets = `[connections.gsheets]
spreadsheet = "https://docs.google.com/spreadsheets/d/TU_ID_DE_HOJA_AQUI/edit#gid=0"`;

  const copyToClipboard = (text: string, setCopied: (v: boolean) => void) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="w-full space-y-6 text-xs text-stone-300 font-sans">
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 border border-[#d4af37]/30 flex items-center justify-center bg-[#121212]">
          <Code className="w-4 h-4 text-[#d4af37]" />
        </div>
        <div>
          <h3 className="font-serif text-sm font-semibold text-[#d4af37] tracking-[0.2em] uppercase">
            DESPLIEGUE STREAMLIT CLOUD
          </h3>
          <p className="text-[10px] text-stone-500 uppercase tracking-widest mt-0.5">Integración perfecta con Google Sheets</p>
        </div>
      </div>

      {/* Secrets Instruction Card */}
      <div className="bg-[#121212] border border-stone-800 rounded-none p-5 space-y-4 shadow-sm">
        <div className="flex items-center gap-2 text-white font-bold uppercase tracking-wider text-[11px]">
          <HelpCircle className="w-4 h-4 text-[#d4af37]" />
          <span>Vincular Google Sheets</span>
        </div>
        
        <p className="text-stone-400 leading-relaxed text-[11px]">
          Sigue estos pasos para conectar tus hojas de cálculo en Streamlit Cloud de forma segura:
        </p>

        <ol className="list-decimal list-inside space-y-2.5 text-stone-300 text-[11px]">
          <li>
            Crea tu Google Sheet con hojas <b>"Inventario"</b> y <b>"Pedidos"</b>.
          </li>
          <li>
            Haz clic en <b>Compartir</b> y selecciona "Cualquier persona con el enlace puede leer/editar".
          </li>
          <li>
            En tu panel de <b>Streamlit Cloud</b>, ve a <i>Settings &gt; Secrets</i> y pega:
          </li>
        </ol>

        <div className="relative mt-2">
          <button
            onClick={() => copyToClipboard(codeSecrets, setCopiedSecrets)}
            className="absolute right-3 top-3 p-1.5 rounded-none bg-stone-900 border border-stone-800 text-stone-400 hover:text-[#d4af37] transition-all"
            title="Copiar Secrets"
          >
            {copiedSecrets ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
          </button>
          <pre className="bg-[#0A0A0A] border border-stone-800 rounded-none p-4 text-[10px] font-mono text-[#d4af37] overflow-x-auto">
            {codeSecrets}
          </pre>
        </div>
      </div>

      {/* requirements.txt Code Block */}
      <div className="space-y-2">
        <div className="flex justify-between items-center px-1">
          <div className="flex items-center gap-2">
            <FileCode className="w-4 h-4 text-[#d4af37]" />
            <span className="font-bold text-stone-200 text-[11px] uppercase tracking-wider">requirements.txt</span>
          </div>
          <button
            onClick={() => copyToClipboard(codeReqs, setCopiedReqs)}
            className="text-[10px] uppercase tracking-wider text-[#d4af37] hover:underline flex items-center gap-1 transition-all"
          >
            {copiedReqs ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            {copiedReqs ? "Copiado" : "Copiar"}
          </button>
        </div>
        <pre className="bg-[#121212] border border-stone-800 rounded-none p-4 text-[11px] font-mono text-stone-300 overflow-x-auto">
          {codeReqs}
        </pre>
      </div>

      {/* app.py Code Block */}
      <div className="space-y-2">
        <div className="flex justify-between items-center px-1">
          <div className="flex items-center gap-2">
            <FileCode className="w-4 h-4 text-[#d4af37]" />
            <span className="font-bold text-stone-200 text-[11px] uppercase tracking-wider">app.py</span>
          </div>
          <button
            onClick={() => copyToClipboard(codeApp, setCopiedApp)}
            className="text-[10px] uppercase tracking-wider text-[#d4af37] hover:underline flex items-center gap-1 transition-all"
          >
            {copiedApp ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            {copiedApp ? "Copiado" : "Copiar"}
          </button>
        </div>
        <pre className="bg-[#121212] border border-stone-800 rounded-none p-4 text-[10px] leading-relaxed font-mono text-stone-400 overflow-x-auto max-h-[280px] overflow-y-auto">
          {codeApp}
        </pre>
      </div>
    </div>
  );
}
