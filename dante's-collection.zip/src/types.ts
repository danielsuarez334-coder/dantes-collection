export type ShirtModel = "Oversized" | "Algodón Licrado";
export type ShirtColor = "Negro" | "Blanco" | "Beige";
export type ShirtSize = "S" | "M" | "L" | "XL";

export interface InventoryItem {
  id: number;
  name: string;
  model: ShirtModel;
  color: ShirtColor;
  size: ShirtSize;
  stock_liso: number;
  stock_apartado: number;
  stock_estampado: number;
}

export type OrderStatus = "Pendiente" | "Finalizado" | "Cancelado";

export interface Order {
  id: number;
  customerName: string;
  model: ShirtModel;
  color: ShirtColor;
  size: ShirtSize;
  quantity: number;
  printDesign: string;
  status: OrderStatus;
  createdAt: string;
  notes: string;
  vendedor: "Daniel" | "Slendy";
}
