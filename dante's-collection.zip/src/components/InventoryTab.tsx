import React, { useState } from "react";
import { InventoryItem } from "../types";
import { Box, Plus, Search, Filter, ShieldAlert } from "lucide-react";

interface InventoryTabProps {
  inventory: InventoryItem[];
  onAddStock: (itemId: number, qtyToAdd: number) => void;
}

export default function InventoryTab({ inventory, onAddStock }: InventoryTabProps) {
  const [colorFilter, setColorFilter] = useState<"Todos" | "Negro" | "Blanco" | "Beige">("Todos");
  const [modelFilter, setModelFilter] = useState<"Todos" | "Oversized" | "Algodón Licrado">("Todos");
  const [selectedItemId, setSelectedItemId] = useState<number>(inventory[0]?.id || 1);
  const [addQty, setAddQty] = useState<number>(10);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Filter inventory items
  const filteredInventory = inventory.filter((item) => {
    const matchesColor = colorFilter === "Todos" || item.color === colorFilter;
    const matchesModel = modelFilter === "Todos" || item.model === modelFilter;
    return matchesColor && matchesModel;
  });

  const handleAddStockSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddStock(selectedItemId, addQty);
    
    const item = inventory.find((i) => i.id === selectedItemId);
    setSuccessMessage(`Se agregaron +${addQty} unidades lisas a "${item?.name}"`);
    setAddQty(10);
    
    setTimeout(() => {
      setSuccessMessage(null);
    }, 4000);
  };

  return (
    <div className="w-full font-sans">
      {/* Overview Cards */}
      <div className="grid grid-cols-3 gap-2.5 mb-6">
        <div className="bg-[#121212] border border-stone-800 rounded-none p-3 text-center">
          <p className="text-[8px] uppercase tracking-[0.15em] text-stone-500 font-semibold mb-1">
            Total Liso
          </p>
          <p className="text-base font-bold text-white">
            {inventory.reduce((sum, item) => sum + item.stock_liso, 0)}
          </p>
        </div>
        <div className="bg-[#121212] border border-stone-800 rounded-none p-3 text-center">
          <p className="text-[8px] uppercase tracking-[0.15em] text-[#d4af37] font-semibold mb-1">
            Apartados
          </p>
          <p className="text-base font-bold text-[#d4af37]">
            {inventory.reduce((sum, item) => sum + item.stock_apartado, 0)}
          </p>
        </div>
        <div className="bg-[#121212] border border-stone-800 rounded-none p-3 text-center">
          <p className="text-[8px] uppercase tracking-[0.15em] text-emerald-500 font-semibold mb-1">
            Estampados
          </p>
          <p className="text-base font-bold text-emerald-400">
            {inventory.reduce((sum, item) => sum + item.stock_estampado, 0)}
          </p>
        </div>
      </div>

      {/* Quick Filters */}
      <div className="bg-[#121212] border border-stone-800 rounded-none p-4 mb-6 space-y-3">
        <div className="flex items-center gap-2 text-[10px] text-stone-300 font-semibold mb-1 uppercase tracking-[0.15em]">
          <Filter className="w-3.5 h-3.5 text-[#d4af37]" />
          <span>Filtros de Variantes</span>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-[9px] uppercase tracking-[0.15em] text-stone-400 font-medium mb-1 block">
              Modelo
            </label>
            <select
              value={modelFilter}
              onChange={(e) => setModelFilter(e.target.value as any)}
              className="w-full bg-[#0A0A0A] border border-stone-800 rounded-none py-2 px-2 text-xs text-stone-300 focus:outline-none uppercase tracking-wider"
            >
              <option value="Todos">Todos</option>
              <option value="Oversized">Oversized</option>
              <option value="Algodón Licrado">Algodón Licrado</option>
            </select>
          </div>

          <div>
            <label className="text-[9px] uppercase tracking-[0.15em] text-stone-400 font-medium mb-1 block">
              Color
            </label>
            <select
              value={colorFilter}
              onChange={(e) => setColorFilter(e.target.value as any)}
              className="w-full bg-[#0A0A0A] border border-stone-800 rounded-none py-2 px-2 text-xs text-stone-300 focus:outline-none uppercase tracking-wider"
            >
              <option value="Todos">Todos</option>
              <option value="Negro">Negro</option>
              <option value="Blanco">Blanco</option>
              <option value="Beige">Beige</option>
            </select>
          </div>
        </div>
      </div>

      {/* Inventory Items List */}
      <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1 border border-stone-800 rounded-none p-2 bg-[#0A0A0A] mb-6">
        {filteredInventory.map((item) => {
          const isLow = item.stock_liso < 5;
          return (
            <div
              key={item.id}
              className={`bg-[#121212] border rounded-none p-3.5 flex flex-col justify-between transition-all ${
                isLow ? "border-red-900/50" : "border-stone-800"
              }`}
            >
              <div className="flex items-start justify-between gap-1.5">
                <div>
                  <h5 className="text-xs font-bold text-white tracking-wide uppercase">{item.name}</h5>
                  <div className="flex gap-2 mt-1.5">
                    <span className="text-[9px] bg-stone-950 px-1.5 py-0.5 rounded-none border border-stone-800 text-stone-400 uppercase tracking-widest">
                      Talla: <b>{item.size}</b>
                    </span>
                    <span className="text-[9px] bg-stone-950 px-1.5 py-0.5 rounded-none border border-stone-800 text-stone-400 uppercase tracking-widest">
                      Color: <b>{item.color}</b>
                    </span>
                  </div>
                </div>

                {isLow && (
                  <span className="flex items-center gap-1 text-[8px] bg-red-500/10 text-red-400 border border-red-500/20 px-2 py-0.5 rounded-none font-bold uppercase tracking-wider">
                    <ShieldAlert className="w-3 h-3 text-red-400" />
                    Bajo
                  </span>
                )}
              </div>

              {/* Stocks Grid */}
              <div className="grid grid-cols-3 gap-2 mt-3 text-center border-t border-stone-800 pt-2.5">
                <div>
                  <span className="text-[8px] text-stone-500 uppercase tracking-wider font-semibold block mb-0.5">Liso</span>
                  <span className={`text-xs font-bold ${isLow ? "text-red-400 animate-pulse" : "text-stone-300"}`}>
                    {item.stock_liso} u
                  </span>
                </div>
                <div>
                  <span className="text-[8px] text-stone-500 uppercase tracking-wider font-semibold block mb-0.5">Apartado</span>
                  <span className="text-xs font-semibold text-[#d4af37]">
                    {item.stock_apartado} u
                  </span>
                </div>
                <div>
                  <span className="text-[8px] text-stone-500 uppercase tracking-wider font-semibold block mb-0.5">Estampado</span>
                  <span className="text-xs font-semibold text-emerald-400">
                    {item.stock_estampado} u
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Manual Add Stock Form */}
      <div className="bg-[#121212] border border-[#d4af37]/20 rounded-none p-4 shadow-md">
        <div className="flex items-center gap-2 mb-3">
          <Plus className="w-4 h-4 text-[#d4af37]" />
          <h4 className="text-[10px] font-bold text-[#d4af37] uppercase tracking-[0.15em]">Añadir Stock Liso Manual</h4>
        </div>

        {successMessage && (
          <div className="bg-[#0A0A0A] border border-emerald-500/30 text-emerald-200 p-2.5 rounded-none text-xs mb-3">
            {successMessage}
          </div>
        )}

        <form onSubmit={handleAddStockSubmit} className="space-y-4">
          <div>
            <label className="text-[9px] uppercase tracking-[0.15em] text-stone-400 font-medium mb-1 block">
              Seleccionar Camisa (Variante)
            </label>
            <select
              value={selectedItemId}
              onChange={(e) => setSelectedItemId(parseInt(e.target.value))}
              className="w-full bg-[#0A0A0A] border border-stone-800 rounded-none py-2.5 px-3 text-xs text-white focus:outline-none focus:border-[#d4af37]"
            >
              {inventory.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name} (Liso: {item.stock_liso})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3 items-end">
            <div>
              <label className="text-[9px] uppercase tracking-[0.15em] text-stone-400 font-medium mb-1 block">
                Cantidad a Sumar
              </label>
              <input
                type="number"
                min="1"
                required
                value={addQty}
                onChange={(e) => setAddQty(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-full bg-[#0A0A0A] border border-stone-800 rounded-none py-2 px-3 text-xs text-white focus:outline-none focus:border-[#d4af37] font-semibold"
              />
            </div>

            <button
              type="submit"
              className="bg-[#d4af37] hover:bg-[#b8912e] text-black font-bold text-[10px] py-3.5 rounded-none uppercase tracking-[0.15em] transition-all"
            >
              Sumar Stock
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
