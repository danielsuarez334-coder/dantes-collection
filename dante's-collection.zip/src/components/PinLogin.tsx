import React, { useState } from "react";
import { Lock, User, KeyRound, AlertCircle, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface PinLoginProps {
  onLoginSuccess: (vendedor: "Daniel" | "Slendy") => void;
}

export default function PinLogin({ onLoginSuccess }: PinLoginProps) {
  const [selectedUser, setSelectedUser] = useState<"Daniel" | "Slendy">("Daniel");
  const [pin, setPin] = useState<string>("");
  const [error, setError] = useState<string | null>(null);

  const handleKeyPress = (char: string) => {
    setError(null);
    if (pin.length < 4) {
      setPin((prev) => prev + char);
    }
  };

  const handleClear = () => {
    setPin("");
    setError(null);
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (pin === "2026" || pin === "1234") {
      onLoginSuccess(selectedUser);
    } else {
      setError("PIN Incorrecto. Inténtalo de nuevo.");
      setPin("");
    }
  };

  // Keyboard helper click
  const keyClick = (value: string) => {
    if (value === "C") {
      handleClear();
    } else if (value === "OK") {
      handleSubmit();
    } else {
      handleKeyPress(value);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[85vh] px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="w-full max-w-md bg-[#121212] border border-[#d4af37]/30 rounded-none p-8 shadow-2xl flex flex-col items-center"
      >
        {/* Luxury Logo Accent */}
        <div className="w-12 h-12 rounded-none border border-[#d4af37]/30 flex items-center justify-center mb-6">
          <Lock className="w-5 h-5 text-[#d4af37]" strokeWidth={1.5} />
        </div>

        <h1 className="font-serif text-3xl tracking-widest text-[#d4af37] text-center mb-1 uppercase font-bold leading-none">
          DANTE'S
        </h1>
        <h2 className="font-serif text-xl tracking-[0.2em] text-[#d4af37]/80 text-center mb-2 uppercase">
          COLLECTION
        </h2>
        <p className="text-[10px] text-stone-500 uppercase tracking-[0.3em] mb-8 text-center">
          Taller de Camisas Exclusive
        </p>

        {/* User Selector Tabs */}
        <div className="w-full flex bg-[#0A0A0A] rounded-none p-1 border border-stone-800 mb-8">
          <button
            type="button"
            onClick={() => { setSelectedUser("Daniel"); handleClear(); }}
            className={`flex-1 py-2 rounded-none text-xs uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${
              selectedUser === "Daniel"
                ? "bg-[#d4af37] text-black font-semibold"
                : "text-stone-400 hover:text-stone-200"
            }`}
          >
            <User className="w-3.5 h-3.5" />
            Daniel
          </button>
          <button
            type="button"
            onClick={() => { setSelectedUser("Slendy"); handleClear(); }}
            className={`flex-1 py-2 rounded-none text-xs uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${
              selectedUser === "Slendy"
                ? "bg-[#d4af37] text-black font-semibold"
                : "text-stone-400 hover:text-stone-200"
            }`}
          >
            <User className="w-3.5 h-3.5" />
            Slendy
          </button>
        </div>

        <div className="w-full mb-8">
          <p className="text-center text-[10px] text-stone-400 mb-3 font-semibold uppercase tracking-widest">
            Ingresa tu PIN de Seguridad
          </p>
          
          {/* PIN Dots Display */}
          <div className="flex justify-center gap-4 py-2">
            {[0, 1, 2, 3].map((index) => (
              <div
                key={index}
                className={`w-3 h-3 rounded-none transition-all duration-200 ${
                  pin.length > index
                    ? "bg-[#d4af37] rotate-45 scale-110 shadow-[0_0_8px_rgba(212,175,55,0.6)]"
                    : "border border-stone-700 bg-stone-900"
                }`}
              />
            ))}
          </div>
        </div>

        {/* Error notification */}
        <AnimatePresence mode="wait">
          {error && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="w-full mb-5 bg-red-950/20 border border-red-500/30 text-red-200 p-3 rounded-none text-xs flex items-center gap-2"
            >
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{error}</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Safe Vault Keyboard layout */}
        <div className="grid grid-cols-3 gap-3 w-full max-w-[240px] mb-8">
          {["1", "2", "3", "4", "5", "6", "7", "8", "9", "C", "0", "OK"].map((key) => {
            const isSpecial = key === "C" || key === "OK";
            return (
              <button
                key={key}
                type="button"
                onClick={() => keyClick(key)}
                className={`aspect-square rounded-none flex items-center justify-center text-sm font-light border transition-all ${
                  isSpecial
                    ? key === "C"
                      ? "bg-stone-900/40 border-stone-800 text-stone-400 active:bg-stone-800 hover:text-white"
                      : "bg-[#d4af37] border-[#d4af37] text-black active:bg-[#aa8010] hover:brightness-110 font-bold"
                    : "bg-stone-950 border-stone-900 text-white active:bg-stone-900 hover:border-[#d4af37]/40"
                }`}
              >
                {key}
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-1.5 text-stone-500 text-[10px] uppercase tracking-[0.2em]">
          <KeyRound className="w-3.5 h-3.5" />
          <span>PIN: 2026 o 1234</span>
        </div>
      </motion.div>
    </div>
  );
}
