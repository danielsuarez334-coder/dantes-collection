import React, { useState } from "react";
import { ShirtModel, ShirtColor, ShirtSize, InventoryItem, Order } from "../types";
import { ShoppingBag, User, CheckCircle2, ChevronRight, Hash, Feather, MessageSquare, ShieldAlert } from "lucide-react";
import { motion } from "motion/react";

interface NewOrderTabProps {
  inventory: InventoryItem[];
  vendedorSesion: "Daniel" | "Slendy";
  onRegisterOrder: (order: Omit<Order, "id" | "createdAt" | "status">) => void;
}

export default function NewOrderTab({ inventory, vendedorSesion, onRegisterOrder }: NewOrderTabProps) {
  const [customerName, setCustomerName] = useState("");
  const [model, setModel] = useState<ShirtModel>("Oversized");
  const [color, setColor] = useState<ShirtColor>("Negro");
  const [size, setSize] = useState<ShirtSize>("S");
  const [quantity, setQuantity] = useState<number>(1);
  const [printDesign, setPrintDesign] = useState("");
  const [notes, setNotes] = useState("");
  const [vendedor, setVendedor] = useState<"Daniel" | "Slendy">(vendedorSesion);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Find corresponding inventory item
  const selectedItem = inventory.find(
    (item) => item.model === model && item.color === color && item.size === size
  );

  const availableStock = selectedItem ? selectedItem.stock_liso : 0;
  const isOutOfStock = availableStock <= 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!customerName.trim()) {
      alert("Por favor, ingresa el nombre del cliente.");
      return;
    }

    if (quantity <= 0) {
      alert("La cantidad debe ser mayor a 0.");
      return;
    }

    if (quantity > availableStock) {
      alert(`No hay suficiente stock liso disponible. Máximo disponible: ${availableStock}`);
      return;
    }

    // Call callback to add order & adjust stock
    onRegisterOrder({
      customerName: customerName.trim(),
      model,
      color,
      size,
      quantity,
      printDesign: printDesign.trim() || "Liso (Sin estampado)",
      notes: notes.trim(),
      vendedor,
    });

    // Reset Form
    setCustomerName("");
    setPrintDesign("");
    setNotes("");
    setQuantity(1);
    
    setSuccessMsg("¡Pedido registrado exitosamente! Stock reservado.");
    setTimeout(() => {
      setSuccessMsg(null);
    }, 4000);
  };

  return (
    <div className="w-full max-w-md mx-auto">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 border border-[#d4af37]/30 flex items-center justify-center bg-[#121212]">
          <ShoppingBag className="w-4 h-4 text-[#d4af37]" />
        </div>
        <div>
          <h3 className="font-serif text-sm font-semibold text-[#d4af37] tracking-[0.2em] uppercase">
            REGISTRAR PEDIDO
          </h3>
          <p className="text-[10px] text-stone-500 uppercase tracking-widest mt-0.5">Venta y reserva de stock liso</p>
        </div>
      </div>

      {successMsg && (
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-[#121212] border border-emerald-500/30 text-emerald-200 p-4 rounded-none text-xs mb-6 flex items-center gap-3"
        >
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{successMsg}</span>
        </motion.div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Customer Input */}
        <div className="space-y-1.5">
          <label className="text-[10px] uppercase tracking-[0.2em] text-stone-400 font-semibold block">
            Nombre del Cliente
          </label>
          <div className="relative">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-500">
              <User className="w-4 h-4" />
            </span>
            <input
              type="text"
              required
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              placeholder="Ej. Daniel Suárez"
              className="w-full bg-[#121212] border border-stone-800 rounded-none py-3.5 pl-11 pr-4 text-xs text-white focus:outline-none focus:border-[#d4af37] transition-all uppercase tracking-wider"
            />
          </div>
        </div>

        {/* Product selections */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label className="text-[10px] uppercase tracking-[0.2em] text-stone-400 font-semibold block">
              Modelo de Camisa
            </label>
            <select
              value={model}
              onChange={(e) => setModel(e.target.value as ShirtModel)}
              className="w-full bg-[#121212] border border-stone-800 rounded-none py-3.5 px-3.5 text-xs text-white focus:outline-none focus:border-[#d4af37] transition-all uppercase tracking-wider"
            >
              <option value="Oversized">Oversized</option>
              <option value="Algodón Licrado">Algodón Licrado</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-[10px] uppercase tracking-[0.2em] text-stone-400 font-semibold block">
              Color
            </label>
            <select
              value={color}
              onChange={(e) => setColor(e.target.value as ShirtColor)}
              className="w-full bg-[#121212] border border-stone-800 rounded-none py-3.5 px-3.5 text-xs text-white focus:outline-none focus:border-[#d4af37] transition-all uppercase tracking-wider"
            >
              <option value="Negro">Negro</option>
              <option value="Blanco">Blanco</option>
              <option value="Beige">Beige</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label className="text-[10px] uppercase tracking-[0.2em] text-stone-400 font-semibold block">
              Talla
            </label>
            <select
              value={size}
              onChange={(e) => setSize(e.target.value as ShirtSize)}
              className="w-full bg-[#121212] border border-stone-800 rounded-none py-3.5 px-3.5 text-xs text-white focus:outline-none focus:border-[#d4af37] transition-all font-semibold"
            >
              <option value="S">S</option>
              <option value="M">M</option>
              <option value="L">L</option>
              <option value="XL">XL</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-[10px] uppercase tracking-[0.2em] text-stone-400 font-semibold block">
              Cantidad
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-500">
                <Hash className="w-4 h-4" />
              </span>
              <input
                type="number"
                min="1"
                required
                value={quantity}
                onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-full bg-[#121212] border border-stone-800 rounded-none py-3.5 pl-11 pr-4 text-xs text-white focus:outline-none focus:border-[#d4af37] transition-all font-semibold"
              />
            </div>
          </div>
        </div>

        {/* Live inventory info badge */}
        <div className={`p-4 rounded-none border flex items-center justify-between transition-all ${
          isOutOfStock 
            ? "bg-[#1a0f0f] border-red-500/20 text-red-300" 
            : "bg-[#121212] border-stone-800 text-stone-300"
        }`}>
          <div className="flex items-center gap-2">
            <ShieldAlert className={`w-4 h-4 ${isOutOfStock ? "text-red-400 animate-pulse" : "text-[#d4af37]"}`} />
            <span className="text-[10px] uppercase tracking-wider font-medium">Disponibilidad lisa:</span>
          </div>
          <span className={`text-xs font-bold ${isOutOfStock ? "text-red-400" : "text-[#d4af37]"}`}>
            {availableStock} uds {isOutOfStock && "(AGOTADO)"}
          </span>
        </div>

        {/* Stamp pattern (estampado) */}
        <div className="space-y-1.5">
          <label className="text-[10px] uppercase tracking-[0.2em] text-stone-400 font-semibold block">
            Diseño de Estampado (simple)
          </label>
          <div className="relative">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-500">
              <Feather className="w-4 h-4" />
            </span>
            <input
              type="text"
              value={printDesign}
              onChange={(e) => setPrintDesign(e.target.value)}
              placeholder="Ej. Logo Dante en espalda (Dorado)"
              className="w-full bg-[#121212] border border-stone-800 rounded-none py-3.5 pl-11 pr-4 text-xs text-white focus:outline-none focus:border-[#d4af37] transition-all"
            />
          </div>
        </div>

        {/* Seller selection & Notes */}
        <div className="grid grid-cols-1 gap-4">
          <div className="space-y-1.5">
            <label className="text-[10px] uppercase tracking-[0.2em] text-stone-400 font-semibold block">
              Vendedor
            </label>
            <select
              value={vendedor}
              onChange={(e) => setVendedor(e.target.value as "Daniel" | "Slendy")}
              className="w-full bg-[#121212] border border-stone-800 rounded-none py-3.5 px-3.5 text-xs text-white focus:outline-none focus:border-[#d4af37] transition-all uppercase tracking-wider"
            >
              <option value="Daniel">Daniel</option>
              <option value="Slendy">Slendy</option>
            </select>
          </div>
        </div>

        <div className="space-y-1.5">
          <label className="text-[10px] uppercase tracking-[0.2em] text-stone-400 font-semibold block">
            Notas / Observaciones
          </label>
          <div className="relative">
            <span className="absolute left-3.5 top-3.5 text-stone-500">
              <MessageSquare className="w-4 h-4" />
            </span>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Ej. Cliente solicitó empaque de regalo..."
              rows={3}
              className="w-full bg-[#121212] border border-stone-800 rounded-none py-3 pl-11 pr-4 text-xs text-white focus:outline-none focus:border-[#d4af37] transition-all"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={isOutOfStock || !customerName.trim()}
          className={`w-full py-4 rounded-none font-bold tracking-[0.2em] text-xs transition-all duration-300 flex items-center justify-center gap-2 uppercase ${
            isOutOfStock || !customerName.trim()
              ? "bg-stone-900 text-stone-600 cursor-not-allowed border border-stone-950"
              : "bg-[#d4af37] text-black hover:bg-[#b8912e] active:scale-[0.99]"
          }`}
        >
          Confirmar Pedido <ChevronRight className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
}
