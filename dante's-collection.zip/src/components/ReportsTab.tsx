import React from "react";
import { Order, InventoryItem } from "../types";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, PieChart, Pie, Legend } from "recharts";
import { TrendingUp, Users, ShoppingBag, CheckCircle, Percent, Shirt } from "lucide-react";

interface ReportsTabProps {
  orders: Order[];
  inventory: InventoryItem[];
}

export default function ReportsTab({ orders, inventory }: ReportsTabProps) {
  // Filter active sales (non-cancelled orders)
  const activeOrders = orders.filter((o) => o.status !== "Cancelado");

  // --- CHART 1: Sales by Vendedor ---
  const danielSales = activeOrders
    .filter((o) => o.vendedor === "Daniel")
    .reduce((sum, o) => sum + o.quantity, 0);

  const slendySales = activeOrders
    .filter((o) => o.vendedor === "Slendy")
    .reduce((sum, o) => sum + o.quantity, 0);

  const sellerData = [
    { name: "Daniel", ventas: danielSales, color: "#d4af37" },
    { name: "Slendy", ventas: slendySales, color: "#f39c12" },
  ];

  // --- CHART 2: Sales by Shirt Variant ---
  const variantSalesMap: { [key: string]: number } = {};
  activeOrders.forEach((o) => {
    const key = `${o.model} ${o.color}`;
    variantSalesMap[key] = (variantSalesMap[key] || 0) + o.quantity;
  });

  const variantData = Object.keys(variantSalesMap).map((key) => ({
    name: key,
    ventas: variantSalesMap[key],
  })).sort((a, b) => b.ventas - a.ventas).slice(0, 5);

  // --- STATS ---
  const totalOrders = orders.length;
  const totalUnits = activeOrders.reduce((sum, o) => sum + o.quantity, 0);
  const completedOrders = orders.filter((o) => o.status === "Finalizado").length;
  const pendingOrders = orders.filter((o) => o.status === "Pendiente").length;
  const cancelledOrders = orders.filter((o) => o.status === "Cancelado").length;

  const completionRate = totalOrders > 0 ? Math.round((completedOrders / totalOrders) * 100) : 0;

  return (
    <div className="w-full space-y-6 font-sans">
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 border border-[#d4af37]/30 flex items-center justify-center bg-[#121212]">
          <TrendingUp className="w-4 h-4 text-[#d4af37]" />
        </div>
        <div>
          <h3 className="font-serif text-sm font-semibold text-[#d4af37] tracking-[0.2em] uppercase">
            DESEMPEÑO Y VENTAS
          </h3>
          <p className="text-[10px] text-stone-500 uppercase tracking-widest mt-0.5">Estadísticas en tiempo real de Daniel y Slendy</p>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-[#121212] border border-stone-800 rounded-none p-4 flex flex-col justify-between shadow-sm">
          <div>
            <span className="text-[9px] text-stone-500 font-bold uppercase tracking-[0.15em] block mb-1">
              Camisas Vendidas
            </span>
            <span className="text-2xl font-light text-white">{totalUnits}</span>
          </div>
          <span className="text-[8px] uppercase tracking-wider text-emerald-400 font-medium flex items-center gap-1 mt-3">
            <ShoppingBag className="w-3 h-3" />
            Reservas y Completos
          </span>
        </div>

        <div className="bg-[#121212] border border-stone-800 rounded-none p-4 flex flex-col justify-between shadow-sm">
          <div>
            <span className="text-[9px] text-stone-500 font-bold uppercase tracking-[0.15em] block mb-1">
              Tasa de Entrega
            </span>
            <span className="text-2xl font-light text-[#d4af37]">{completionRate}%</span>
          </div>
          <span className="text-[8px] uppercase tracking-wider text-stone-400 font-medium flex items-center gap-1 mt-3">
            <CheckCircle className="w-3 h-3 text-[#d4af37]" />
            {completedOrders} de {totalOrders} listos
          </span>
        </div>
      </div>

      {/* Mini Stats Breakdown */}
      <div className="grid grid-cols-3 gap-2 text-center bg-[#0A0A0A] border border-stone-800 rounded-none p-3">
        <div>
          <span className="text-[8px] text-stone-500 uppercase tracking-wider block">Pendientes</span>
          <span className="text-xs font-bold text-amber-400">{pendingOrders}</span>
        </div>
        <div>
          <span className="text-[8px] text-stone-500 uppercase tracking-wider block">Entregados</span>
          <span className="text-xs font-bold text-emerald-400">{completedOrders}</span>
        </div>
        <div>
          <span className="text-[8px] text-stone-500 uppercase tracking-wider block">Cancelados</span>
          <span className="text-xs font-bold text-rose-500">{cancelledOrders}</span>
        </div>
      </div>

      {/* Chart 1: Daniel vs Slendy */}
      <div className="bg-[#121212] border border-stone-800 rounded-none p-4 shadow-sm">
        <h4 className="text-[10px] font-bold text-white uppercase tracking-[0.15em] mb-4 flex items-center gap-2">
          <Users className="w-4 h-4 text-[#d4af37]" />
          Ventas por Vendedor
        </h4>
        
        {totalUnits === 0 ? (
          <div className="text-center py-10 text-stone-600 text-xs uppercase tracking-wider">
            Sin datos de ventas para mostrar.
          </div>
        ) : (
          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={sellerData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="name" stroke="#555" fontSize={10} tickLine={false} />
                <YAxis stroke="#555" fontSize={10} tickLine={false} />
                <Tooltip
                  cursor={{ fill: "rgba(212,175,55,0.03)" }}
                  contentStyle={{ backgroundColor: "#121212", borderColor: "#2c2c2c", borderRadius: 0, fontSize: 11 }}
                />
                <Bar dataKey="ventas" radius={[0, 0, 0, 0]}>
                  {sellerData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      {/* Chart 2: Top Selling Variants */}
      <div className="bg-[#121212] border border-stone-800 rounded-none p-4 shadow-sm">
        <h4 className="text-[10px] font-bold text-white uppercase tracking-[0.15em] mb-4 flex items-center gap-2">
          <Shirt className="w-4 h-4 text-[#d4af37]" />
          Modelos Más Vendidos
        </h4>

        {variantData.length === 0 ? (
          <div className="text-center py-10 text-stone-600 text-xs uppercase tracking-wider">
            Registra pedidos para ver el ranking.
          </div>
        ) : (
          <div className="space-y-4">
            {variantData.map((item, index) => {
              const percentages = totalUnits > 0 ? Math.round((item.ventas / totalUnits) * 100) : 0;
              return (
                <div key={item.name} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-semibold text-stone-300">
                      #{index + 1} {item.name}
                    </span>
                    <span className="text-stone-400 font-medium text-[11px]">
                      {item.ventas} uds ({percentages}%)
                    </span>
                  </div>
                  {/* Progress bar */}
                  <div className="w-full h-1.5 bg-[#0A0A0A] rounded-none overflow-hidden">
                    <div
                      className="h-full bg-[#d4af37]"
                      style={{ width: `${percentages}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
