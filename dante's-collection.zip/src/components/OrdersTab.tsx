import React, { useState } from "react";
import { Order, OrderStatus } from "../types";
import { Check, X, Search, Filter, Calendar, User, Tag, FileText, ShoppingCart } from "lucide-react";

interface OrdersTabProps {
  orders: Order[];
  onCompleteOrder: (orderId: number) => void;
  onCancelOrder: (orderId: number) => void;
}

export default function OrdersTab({ orders, onCompleteOrder, onCancelOrder }: OrdersTabProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<"Todos" | OrderStatus>("Todos");
  const [vendedorFilter, setVendedorFilter] = useState<"Todos" | "Daniel" | "Slendy">("Todos");

  // Filter orders
  const filteredOrders = orders.filter((order) => {
    const matchesSearch =
      order.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.id.toString() === searchTerm.trim() ||
      order.printDesign.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "Todos" || order.status === statusFilter;
    const matchesVendedor = vendedorFilter === "Todos" || order.vendedor === vendedorFilter;

    return matchesSearch && matchesStatus && matchesVendedor;
  });

  return (
    <div className="w-full">
      {/* Search and Filters */}
      <div className="bg-[#121212] border border-stone-800 rounded-none p-4 mb-6 space-y-3 shadow-md">
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-500" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Buscar por cliente, ID o diseño..."
            className="w-full bg-[#0A0A0A] border border-stone-800 rounded-none py-2.5 pl-10 pr-4 text-xs text-white placeholder-stone-500 focus:outline-none focus:border-[#d4af37]/60"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-[10px] uppercase tracking-[0.15em] text-stone-400 font-semibold mb-1 block">
              Estado
            </label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="w-full bg-[#0A0A0A] border border-stone-800 rounded-none py-2 px-2 text-xs text-stone-300 focus:outline-none uppercase tracking-wider"
            >
              <option value="Todos">Todos</option>
              <option value="Pendiente">Pendientes ⏳</option>
              <option value="Finalizado">Finalizados ✅</option>
              <option value="Cancelado">Cancelados ❌</option>
            </select>
          </div>

          <div>
            <label className="text-[10px] uppercase tracking-[0.15em] text-stone-400 font-semibold mb-1 block">
              Vendedor
            </label>
            <select
              value={vendedorFilter}
              onChange={(e) => setVendedorFilter(e.target.value as any)}
              className="w-full bg-[#0A0A0A] border border-stone-800 rounded-none py-2 px-2 text-xs text-stone-300 focus:outline-none uppercase tracking-wider"
            >
              <option value="Todos">Todos</option>
              <option value="Daniel">Daniel</option>
              <option value="Slendy">Slendy</option>
            </select>
          </div>
        </div>
      </div>

      {/* Orders list */}
      <div className="space-y-4">
        {filteredOrders.length === 0 ? (
          <div className="text-center py-12 border border-stone-800 rounded-none bg-[#121212]">
            <ShoppingCart className="w-8 h-8 text-stone-600 mx-auto mb-3" strokeWidth={1.5} />
            <p className="text-stone-400 text-xs uppercase tracking-wider">No se encontraron pedidos.</p>
            <p className="text-stone-600 text-[10px] mt-1 uppercase tracking-wider">Intenta ajustando los filtros de búsqueda.</p>
          </div>
        ) : (
          filteredOrders.map((order) => {
            // Stylings based on status
            let statusBadgeColor = "";
            if (order.status === "Pendiente") {
              statusBadgeColor = "bg-amber-500/10 text-amber-400 border-amber-500/20";
            } else if (order.status === "Finalizado") {
              statusBadgeColor = "bg-emerald-500/10 text-emerald-400 border-emerald-500/20";
            } else {
              statusBadgeColor = "bg-rose-500/10 text-rose-400 border-rose-500/20";
            }

            return (
              <div
                key={order.id}
                className="bg-[#121212] border border-stone-800 rounded-none p-5 shadow-sm hover:border-[#d4af37]/30 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-4">
                    <div>
                      <span className="text-[9px] bg-stone-950 border border-stone-800 px-2 py-0.5 rounded-none text-stone-400 font-bold uppercase tracking-[0.15em]">
                        PEDIDO #{order.id}
                      </span>
                      <h4 className="font-serif text-base font-bold text-white tracking-wide mt-2 uppercase">
                        {order.customerName}
                      </h4>
                    </div>
                    <span className={`text-[9px] uppercase tracking-wider px-2.5 py-1 rounded-none border font-semibold ${statusBadgeColor}`}>
                      {order.status}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-y-2.5 gap-x-2 text-xs border-y border-stone-800 py-3 my-3">
                    <div className="flex items-center gap-2 text-stone-300">
                      <Tag className="w-3.5 h-3.5 text-[#d4af37]" />
                      <span className="font-medium">
                        {order.model} ({order.color} / {order.size})
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-stone-300 justify-end">
                      <span className="text-stone-500">Cant:</span>
                      <span className="font-bold text-white bg-stone-950 px-2 py-0.5 rounded-none border border-stone-800">
                        {order.quantity} uds
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-stone-300 col-span-2">
                      <FileText className="w-3.5 h-3.5 text-[#d4af37] shrink-0" />
                      <span className="truncate">
                        <span className="text-stone-500">Diseño:</span> {order.printDesign}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-stone-400">
                      <User className="w-3.5 h-3.5 text-stone-600" />
                      <span>Vendió: <b className="text-[#d4af37]">{order.vendedor}</b></span>
                    </div>

                    <div className="flex items-center gap-2 text-stone-400 justify-end">
                      <Calendar className="w-3.5 h-3.5 text-stone-600" />
                      <span className="text-[10px]">
                        {order.createdAt.split(" ")[0]}
                      </span>
                    </div>
                  </div>

                  {order.notes && (
                    <div className="text-[11px] bg-[#0A0A0A] border border-stone-800 rounded-none p-3 text-stone-400 italic mb-4">
                      <strong>Notas:</strong> {order.notes}
                    </div>
                  )}
                </div>

                {/* Actions (Only when status is Pendiente) */}
                {order.status === "Pendiente" && (
                  <div className="grid grid-cols-2 gap-3 mt-1 pt-2 border-t border-stone-800">
                    <button
                      type="button"
                      onClick={() => onCompleteOrder(order.id)}
                      className="bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/20 text-emerald-400 py-2.5 rounded-none font-bold text-[10px] tracking-[0.15em] uppercase transition-all flex items-center justify-center gap-1.5"
                    >
                      <Check className="w-4 h-4" />
                      Completar
                    </button>
                    <button
                      type="button"
                      onClick={() => onCancelOrder(order.id)}
                      className="bg-rose-500/5 hover:bg-rose-500/15 border border-rose-500/20 text-rose-400 py-2.5 rounded-none font-semibold text-[10px] tracking-[0.15em] uppercase transition-all flex items-center justify-center gap-1.5"
                    >
                      <X className="w-4 h-4" />
                      Cancelar
                    </button>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
