import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import datetime
from streamlit_gsheets import GSheetsConnection

# ==========================================
# 1. CONFIGURACIÓN DE PÁGINA E IDENTIDAD
# ==========================================
st.set_page_config(
    page_title="Dante's Collection",
    page_icon="👑",
    layout="centered", # Centrado ideal para celulares
    initial_sidebar_state="collapsed"
)

# Estilos CSS personalizados para la paleta de colores: Negro, Dorado/Amarillo y Blanco
st.markdown("""
    <style>
    /* Fondo principal y textos */
    .stApp {
        background-color: #0d0d0d;
        color: #ffffff;
    }
    
    /* Títulos y cabeceras en Dorado */
    h1, h2, h3, .gold-text {
        color: #f39c12 !important;
        font-family: 'Helvetica Neue', Arial, sans-serif;
        font-weight: bold;
        text-align: center;
    }
    
    /* Estilo para tarjetas y contenedores */
    .card {
        background-color: #1a1a1a;
        padding: 20px;
        border-radius: 10px;
        border: 1px solid #f39c12;
        margin-bottom: 15px;
    }
    
    /* Inputs de texto y selectores */
    div[data-baseweb="select"] > div, div[data-baseweb="input"] > div {
        background-color: #222222 !important;
        color: #ffffff !important;
        border-color: #f39c12 !important;
    }
    
    /* Botones primarios en dorado con texto negro */
    .stButton>button {
        background-color: #f39c12 !important;
        color: #000000 !important;
        font-weight: bold !important;
        border: none !important;
        border-radius: 5px !important;
        width: 100%;
        transition: all 0.3s ease;
    }
    
    .stButton>button:hover {
        background-color: #e67e22 !important;
        color: #000000 !important;
        box-shadow: 0 0 10px #f39c12;
    }
    
    /* Etiquetas de pestañas */
    .stTabs [data-baseweb="tab-list"] {
        gap: 8px;
        background-color: #111111;
        padding: 5px;
        border-radius: 8px;
    }
    
    .stTabs [data-baseweb="tab"] {
        height: 45px;
        white-space: pre-wrap;
        background-color: #1a1a1a;
        border-radius: 5px;
        color: #cccccc;
        font-size: 14px;
        border: 1px solid #333333;
    }
    
    .stTabs [aria-selected="true"] {
        background-color: #f39c12 !important;
        color: #000000 !important;
        font-weight: bold;
        border: 1px solid #f39c12 !important;
    }
    </style>
""", unsafe_allow_html=True)

# Title Header
st.markdown("<h1>👑 DANTE'S COLLECTION 👑</h1>", unsafe_allow_html=True)
st.markdown("<p style='text-align: center; color: #888888; font-style: italic;'>Taller de Camisas Exclusive</p>", unsafe_allow_html=True)

# ==========================================
# 2. SISTEMA DE SEGURIDAD (PANTALLA DE PIN)
# ==========================================
if "authenticated" not in st.session_state:
    st.session_state.authenticated = False
if "usuario" not in st.session_state:
    st.session_state.usuario = ""

if not st.session_state.authenticated:
    st.markdown("<div class='card'>", unsafe_allow_html=True)
    st.markdown("<h3 style='color: #f39c12; text-align: center;'>🔒 Acceso Privado</h3>", unsafe_allow_html=True)
    
    pin_input = st.text_input("Ingrese su PIN de Acceso:", type="password", help="PIN exclusivo para Daniel y Slendy")
    col1, col2 = st.columns(2)
    with col1:
        vendedor_login = st.selectbox("¿Quién ingresa?", ["Daniel", "Slendy"])
        
    with col2:
        st.write("")
        st.write("")
        btn_login = st.button("Ingresar")
        
    if btn_login:
        if pin_input in ["2026", "1234"]:
            st.session_state.authenticated = True
            st.session_state.usuario = vendedor_login
            st.success(f"¡Bienvenido, {vendedor_login}! Cargando sistema...")
            st.rerun()
        else:
            st.error("❌ PIN Incorrecto. Intente nuevamente.")
    st.markdown("</div>", unsafe_allow_html=True)
    st.stop() # Detiene la ejecución para no mostrar el contenido de abajo

# Mostrar sesión de usuario en la barra superior
st.markdown(f"<p style='text-align: right; color: #f39c12; font-weight: bold; margin-bottom: 20px;'>👤 Sesión activa: {st.session_state.usuario} | <a href='?logout=true' style='color:#e74c3c;text-decoration:none;'>Salir</a></p>", unsafe_allow_html=True)

# Logout query param handler
query_params = st.query_params
if "logout" in query_params:
    st.session_state.authenticated = False
    st.session_state.usuario = ""
    st.query_params.clear()
    st.rerun()

# ==========================================
# 3. CONEXIÓN A GOOGLE SHEETS
# ==========================================
# Se asume la configuración en secrets.toml o la configuración de Streamlit Cloud.
# Se crea la conexión a Google Sheets.
try:
    conn = st.connection("gsheets", type=GSheetsConnection)
except Exception as e:
    st.error("Error al inicializar la conexión con Google Sheets. Asegúrate de configurar los secrets.")
    st.info("Revisa las instrucciones al final o en la documentación de Streamlit.")
    st.stop()

# Helper para leer los datos de Inventario
@st.cache_data(ttl=5) # Cache de 5 segundos para que sea rápido pero dinámico
def cargar_inventario():
    try:
        # worksheet="Inventario" es la pestaña con los datos de inventario
        df = conn.read(worksheet="Inventario", ttl=5)
        # Limpiar columnas
        df.columns = [c.strip() for c in df.columns]
        return df
    except Exception as e:
        # Si la hoja no existe o está vacía, creamos el DataFrame inicial de 24 variantes
        st.warning("⚠️ No se pudo leer la hoja 'Inventario'. Creando inventario por defecto...")
        
        modelos = ["Oversized", "Algodón Licrado"]
        colores = ["Negro", "Blanco", "Beige"] # 3 colores elegantes
        tallas = ["S", "M", "L", "XL"] # 4 tallas
        
        rows = []
        idx = 1
        for model in modelos:
            for color in colores:
                for size in tallas:
                    rows.append({
                        "id": idx,
                        "name": f"Camisa {model} {color} {size}",
                        "color": color,
                        "size": size,
                        "stock_liso": 50, # Stock inicial liso de prueba
                        "stock_apartado": 0,
                        "stock_estampado": 0
                    })
                    idx += 1
        df_init = pd.DataFrame(rows)
        # Intentamos guardarlo
        try:
            conn.update(worksheet="Inventario", data=df_init)
        except Exception as update_err:
            pass
        return df_init

# Helper para leer los datos de Pedidos
@st.cache_data(ttl=5)
def cargar_pedidos():
    try:
        df = conn.read(worksheet="Pedidos", ttl=5)
        df.columns = [c.strip() for c in df.columns]
        return df
    except Exception as e:
        # Si la hoja no existe o está vacía, creamos un DataFrame vacío estructurado
        df_empty = pd.DataFrame(columns=[
            "id", "customerName", "model", "color", "size", 
            "quantity", "printDesign", "status", "createdAt", "notes", "vendedor"
        ])
        return df_empty

# Guardar cambios de inventario
def guardar_inventario(df):
    conn.update(worksheet="Inventario", data=df)
    st.cache_data.clear()

# Guardar cambios de pedidos
def guardar_pedidos(df):
    conn.update(worksheet="Pedidos", data=df)
    st.cache_data.clear()


# Cargar los datos actuales
df_inv = cargar_inventario()
df_ped = cargar_pedidos()

# Asegurar tipos de datos correctos para inventario
df_inv["id"] = df_inv["id"].astype(int)
df_inv["stock_liso"] = df_inv["stock_liso"].astype(int)
df_inv["stock_apartado"] = df_inv["stock_apartado"].astype(int)
df_inv["stock_estampado"] = df_inv["stock_estampado"].astype(int)

# Asegurar tipos de datos correctos para pedidos
if not df_ped.empty:
    df_ped["id"] = df_ped["id"].astype(int)
    df_ped["quantity"] = df_ped["quantity"].astype(int)

# ==========================================
# 4. PESTAÑAS DE LA APLICACIÓN (MÓVIL FRIENDLY)
# ==========================================
tab_nuevo, tab_gestion, tab_inventario, tab_reportes = st.tabs([
    "🛒 Nuevo Pedido", 
    "📦 Gestión", 
    "🗃️ Inventario", 
    "📊 Reportes"
])

# --------------------------------------------------
# PESTAÑA: NUEVO PEDIDO
# --------------------------------------------------
with tab_nuevo:
    st.markdown("<h3 style='color: #f39c12;'>📝 Registrar Nuevo Pedido</h3>", unsafe_allow_html=True)
    
    with st.form("form_pedido"):
        customer_name = st.text_input("Cliente:", placeholder="Nombre del cliente")
        
        # Filtros de Producto
        model_select = st.selectbox("Modelo de Camisa:", ["Oversized", "Algodón Licrado"])
        color_select = st.selectbox("Color:", sorted(df_inv["color"].unique()))
        size_select = st.selectbox("Talla:", ["S", "M", "L", "XL"])
        
        # Obtener stock liso disponible para validación
        match_inv = df_inv[
            (df_inv["name"].str.contains(model_select)) & 
            (df_inv["color"] == color_select) & 
            (df_inv["size"] == size_select)
        ]
        
        stock_disponible = 0
        variant_id = None
        if not match_inv.empty:
            stock_disponible = int(match_inv.iloc[0]["stock_liso"])
            variant_id = int(match_inv.iloc[0]["id"])
            st.info(f"💡 Stock liso disponible actual: {stock_disponible} unidades.")
        else:
            st.warning("⚠️ No se encontró esta variante en el inventario.")
            
        quantity = st.number_input("Cantidad:", min_value=1, value=1, step=1)
        print_design = st.text_input("Diseño del Estampado (simple):", placeholder="Ej: Logo Dante Dorado")
        notes = st.text_area("Notas / Observaciones:", placeholder="Detalles adicionales del pedido...")
        
        # El vendedor es por defecto el de la sesión, pero se puede cambiar si es necesario
        vendedor_pedido = st.selectbox("Vendedor:", ["Daniel", "Slendy"], index=0 if st.session_state.usuario == "Daniel" else 1)
        
        btn_registrar = st.form_submit_button("Confirmar Pedido 🚀")
        
        if btn_registrar:
            if not customer_name.strip():
                st.error("❌ Por favor ingrese el nombre del cliente.")
            elif variant_id is None:
                st.error("❌ Variante de producto no válida.")
            elif quantity > stock_disponible:
                st.error(f"❌ Stock insuficiente. Solo tienes {stock_disponible} unidades disponibles de esta camisa lisa.")
            else:
                # LÓGICA DE NEGOCIO:
                # Restar de [stock_liso] y sumar a [stock_apartado]
                df_inv.loc[df_inv["id"] == variant_id, "stock_liso"] -= quantity
                df_inv.loc[df_inv["id"] == variant_id, "stock_apartado"] += quantity
                
                # Crear nuevo pedido
                new_id = 1 if df_ped.empty else int(df_ped["id"].max()) + 1
                new_order = pd.DataFrame([{
                    "id": new_id,
                    "customerName": customer_name.strip(),
                    "model": model_select,
                    "color": color_select,
                    "size": size_select,
                    "quantity": int(quantity),
                    "printDesign": print_design.strip() if print_design.strip() else "Liso",
                    "status": "Pendiente", # Estados: Pendiente, Finalizado, Cancelado
                    "createdAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "notes": notes.strip(),
                    "vendedor": vendedor_pedido
                }])
                
                df_ped = pd.concat([df_ped, new_order], ignore_index=True)
                
                # Guardar bases de datos
                guardar_inventario(df_inv)
                guardar_pedidos(df_ped)
                
                st.success(f"🎉 ¡Pedido #{new_id} registrado con éxito! Se apartaron {quantity} camisas.")
                st.balloons()
                st.rerun()

# --------------------------------------------------
# PESTAÑA: GESTIÓN DE PEDIDOS
# --------------------------------------------------
with tab_gestion:
    st.markdown("<h3 style='color: #f39c12;'>📦 Listado y Gestión de Pedidos</h3>", unsafe_allow_html=True)
    
    if df_ped.empty:
        st.info("No hay pedidos registrados en el sistema.")
    else:
        # Filtrar por estado para mejor organización
        filtro_estado = st.selectbox("Filtrar por Estado:", ["Todos", "Pendiente", "Finalizado", "Cancelado"])
        
        if filtro_estado != "Todos":
            pedidos_filtrados = df_ped[df_ped["status"] == filtro_estado]
        else:
            pedidos_filtrados = df_ped
            
        # Mostrar pedidos en formato tarjeta (Móvil Friendly)
        for index, row in pedidos_filtrados.iterrows():
            with st.container():
                st.markdown(f"""
                <div class='card'>
                    <h4 style='color:#f39c12; margin:0;'>Pedido #{row['id']} - {row['customerName']}</h4>
                    <p style='margin:5px 0;'><b>Producto:</b> {row['model']} ({row['color']} - Talla {row['size']})</p>
                    <p style='margin:5px 0;'><b>Cantidad:</b> {row['quantity']} | <b>Estampado:</b> {row['printDesign']}</p>
                    <p style='margin:5px 0;'><b>Vendedor:</b> {row['vendedor']} | <b>Fecha:</b> {row['createdAt']}</p>
                    <p style='margin:5px 0; color:#aaa;'><b>Notas:</b> {row['notes']}</p>
                </div>
                """, unsafe_allow_html=True)
                
                # Acciones solo si está Pendiente
                if row['status'] == "Pendiente":
                    col_btn1, col_btn2 = st.columns(2)
                    
                    with col_btn1:
                        if st.button(f"Completar #{row['id']}", key=f"fin_{row['id']}"):
                            # LÓGICA DE NEGOCIO: Al finalizar:
                            # Restar de [stock_apartado], sumar a [stock_estampado]
                            qty = int(row['quantity'])
                            # Buscar variante en inventario
                            match_v = df_inv[
                                (df_inv["name"].str.contains(row['model'])) &
                                (df_inv["color"] == row['color']) &
                                (df_inv["size"] == row['size'])
                            ]
                            if not match_v.empty:
                                v_id = match_v.iloc[0]["id"]
                                # Asegurar que haya suficiente en apartado
                                df_inv.loc[df_inv["id"] == v_id, "stock_apartado"] -= qty
                                df_inv.loc[df_inv["id"] == v_id, "stock_estampado"] += qty
                                
                                # Actualizar estado del pedido
                                df_ped.loc[df_ped["id"] == row['id'], "status"] = "Finalizado"
                                
                                # Guardar cambios
                                guardar_inventario(df_inv)
                                guardar_pedidos(df_ped)
                                st.success(f"Pedido #{row['id']} completado y stock transferido a Estampado.")
                                st.rerun()
                            else:
                                st.error("No se pudo localizar la variante en el inventario.")
                                
                    with col_btn2:
                        if st.button(f"Cancelar #{row['id']}", key=f"can_{row['id']}"):
                            # LÓGICA DE NEGOCIO: Al cancelar:
                            # Devolver stock a [stock_liso] (restar de apartado)
                            qty = int(row['quantity'])
                            match_v = df_inv[
                                (df_inv["name"].str.contains(row['model'])) &
                                (df_inv["color"] == row['color']) &
                                (df_inv["size"] == row['size'])
                            ]
                            if not match_v.empty:
                                v_id = match_v.iloc[0]["id"]
                                df_inv.loc[df_inv["id"] == v_id, "stock_apartado"] -= qty
                                df_inv.loc[df_inv["id"] == v_id, "stock_liso"] += qty
                                
                                # Actualizar estado del pedido
                                df_ped.loc[df_ped["id"] == row['id'], "status"] = "Cancelado"
                                
                                # Guardar cambios
                                guardar_inventario(df_inv)
                                guardar_pedidos(df_ped)
                                st.success(f"Pedido #{row['id']} cancelado. El stock fue devuelto a Liso.")
                                st.rerun()
                else:
                    st.markdown(f"<p style='text-align: center; font-weight: bold; color: {'#2ecc71' if row['status'] == 'Finalizado' else '#e74c3c'};'>Estado: {row['status']}</p>", unsafe_allow_html=True)
                
                st.markdown("<hr style='border-color: #333;' />", unsafe_allow_html=True)

# --------------------------------------------------
# PESTAÑA: INVENTARIO (24 VARIANTES)
# --------------------------------------------------
with tab_inventario:
    st.markdown("<h3 style='color: #f39c12;'>🗃️ Control de Inventario (24 Variantes)</h3>", unsafe_allow_html=True)
    
    # Buscador rápido
    search_color = st.selectbox("Filtrar por Color:", ["Todos"] + list(df_inv["color"].unique()))
    search_model = st.selectbox("Filtrar por Modelo:", ["Todos", "Oversized", "Algodón Licrado"])
    
    filtered_inv = df_inv
    if search_color != "Todos":
        filtered_inv = filtered_inv[filtered_inv["color"] == search_color]
    if search_model != "Todos":
        filtered_inv = filtered_inv[filtered_inv["name"].str.contains(search_model)]
        
    # Mostrar tabla interactiva o tarjetas editables
    st.dataframe(
        filtered_inv[["id", "name", "stock_liso", "stock_apartado", "stock_estampado"]],
        use_container_width=True,
        hide_index=True
    )
    
    # Formulario para recargar stock liso manualmente
    st.markdown("<div class='card'>", unsafe_allow_html=True)
    st.markdown("<h4 style='color: #f39c12; text-align: center;'>➕ Agregar Stock Liso</h4>", unsafe_allow_html=True)
    
    with st.form("form_add_stock"):
        select_variant_to_add = st.selectbox(
            "Seleccione Variante:", 
            df_inv["name"].tolist()
        )
        qty_to_add = st.number_input("Cantidad de camisas lisas a agregar:", min_value=1, value=10, step=1)
        btn_add_stock = st.form_submit_button("Añadir Stock")
        
        if btn_add_stock:
            df_inv.loc[df_inv["name"] == select_variant_to_add, "stock_liso"] += qty_to_add
            guardar_inventario(df_inv)
            st.success(f"¡Se añadieron {qty_to_add} unidades a {select_variant_to_add}!")
            st.rerun()
    st.markdown("</div>", unsafe_allow_html=True)

# --------------------------------------------------
# PESTAÑA: REPORTES Y GRÁFICAS
# --------------------------------------------------
with tab_reportes:
    st.markdown("<h3 style='color: #f39c12;'>📊 Reporte de Ventas y Rendimiento</h3>", unsafe_allow_html=True)
    
    if df_ped.empty:
        st.info("No hay datos de pedidos suficientes para graficar.")
    else:
        # Filtrar solo pedidos confirmados (Pendiente + Finalizado) para reportes de venta real
        df_ventas = df_ped[df_ped["status"] != "Cancelado"]
        
        if df_ventas.empty:
            st.warning("No hay pedidos activos (Pendientes o Finalizados) para graficar.")
        else:
            # 1. GRÁFICA DE VENDEDORES (Daniel vs Slendy)
            st.markdown("<h4>🏆 Ventas por Vendedor (Unidades totales)</h4>", unsafe_allow_html=True)
            sales_by_vendedor = df_ventas.groupby("vendedor")["quantity"].sum().reset_index()
            
            # Asegurar que ambos vendedores aparezcan aunque tengan 0
            for vend in ["Daniel", "Slendy"]:
                if vend not in sales_by_vendedor["vendedor"].values:
                    sales_by_vendedor = pd.concat([
                        sales_by_vendedor, 
                        pd.DataFrame([{"vendedor": vend, "quantity": 0}])
                    ], ignore_index=True)
            
            fig_vendedor = px.bar(
                sales_by_vendedor,
                x="vendedor",
                y="quantity",
                color="vendedor",
                color_discrete_map={"Daniel": "#f39c12", "Slendy": "#f1c40f"},
                labels={"vendedor": "Vendedor", "quantity": "Camisas Vendidas"},
                template="plotly_dark"
            )
            fig_vendedor.update_layout(
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(0,0,0,0)',
                showlegend=False
            )
            st.plotly_chart(fig_vendedor, use_container_width=True)
            
            # 2. GRÁFICA DE CAMISAS MÁS VENDIDAS
            st.markdown("<h4>👕 Camisas más Vendidas (Por Modelo y Color)</h4>", unsafe_allow_html=True)
            df_ventas["modelo_color"] = df_ventas["model"] + " " + df_ventas["color"]
            sales_by_model = df_ventas.groupby("modelo_color")["quantity"].sum().reset_index()
            sales_by_model = sales_by_model.sort_values(by="quantity", ascending=False).head(5)
            
            fig_model = px.bar(
                sales_by_model,
                y="modelo_color",
                x="quantity",
                orientation="h",
                labels={"modelo_color": "Modelo y Color", "quantity": "Cantidad"},
                template="plotly_dark",
                color_discrete_sequence=["#f39c12"]
            )
            fig_model.update_layout(
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(0,0,0,0)'
            )
            st.plotly_chart(fig_model, use_container_width=True)
            
            # Resumen de Métricas Rápidas
            st.markdown("<hr style='border-color:#333;' />", unsafe_allow_html=True)
            st.markdown("<h4>📈 Resumen General</h4>", unsafe_allow_html=True)
            
            col_m1, col_m2, col_m3 = st.columns(3)
            with col_m1:
                total_pedidos = len(df_ped)
                st.metric(label="Total Pedidos", value=total_pedidos)
            with col_m2:
                total_unidades = df_ventas["quantity"].sum()
                st.metric(label="Unidades Vendidas", value=int(total_unidades))
            with col_m3:
                completados = len(df_ped[df_ped["status"] == "Finalizado"])
                st.metric(label="Entregados", value=completados)

# Pie de página elegante
st.markdown("<p style='text-align: center; color: #555555; font-size: 11px; margin-top: 40px;'>👑 Dante's Collection App v2.0 © 2026. Todos los derechos reservados.</p>", unsafe_allow_html=True)
